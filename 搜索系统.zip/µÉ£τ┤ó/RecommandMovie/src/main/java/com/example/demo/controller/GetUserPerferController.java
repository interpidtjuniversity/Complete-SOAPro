package com.example.demo.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.example.demo.dao.PerferRepository;
import com.example.demo.entity.BriefMovie;
import com.example.demo.entity.Perference;
import com.example.demo.entity.UserPerfer;
import com.example.demo.util.MovieUtils;

@Controller
@Configuration
@RequestMapping("mongo")
public class GetUserPerferController {

	@Autowired
	private PerferRepository perferRepository;
	
	@Bean
	@LoadBalanced
	public RestTemplate getMovieRestTemplate() {
		return new RestTemplate();
	}
	
	@GetMapping(value = "moviename")
	@ResponseBody
	@CrossOrigin
	//从MongoDB中获取用户的浏览记录（电影名称)
	public List<String> getMovieName(@RequestParam String id) {
		Optional<UserPerfer> list = perferRepository.findById(id);
		List<String> movieName = new ArrayList<>();
		if(list != null && list.isPresent()) {
			movieName = list.get().getMovieName();
		}
		return movieName;
	}
	
	@GetMapping(value = "briefmovie")
	@ResponseBody
	@CrossOrigin
	//获取为用户推荐的电影信息
	public List<BriefMovie> analyse(@RequestParam String id) {
		RestTemplate restTemplate = getMovieRestTemplate();
		Optional<UserPerfer> list = perferRepository.findById(id);
		List<String> movieId = new ArrayList<>();
		if(list != null && list.isPresent()) {
			movieId = list.get().getMovieId();
		} else {
			for(int i = 1;i<=9;i++) {
				movieId.add(String.valueOf(i));
			}
		}
		String result = restTemplate.postForObject("http://ELASTICSEARCH-SERVER/es/query/recommend", movieId, String.class);
		List<BriefMovie> items = MovieUtils.getMovieInfo(result);
		return items;
	}
	
	@RequestMapping("insert")
	@ResponseBody
	@CrossOrigin
	//向MongoDB中插入用户的点击记录，并获取为用户推荐的电影id
	public String insert(@RequestBody Perference perference) {
		List<String> kinds = perference.getKinds();		
		if(kinds.size() == 0) {
			return "success";
		}
		List<String> movieName = perference.getMovieName();
		String id = perference.getId();
		Optional<UserPerfer> list = perferRepository.findById(id);
		Map<String, Integer> map = null;
		if(list != null && list.isPresent()) {
			map = list.get().getMap();
		} else {
			map = new LinkedHashMap<>();
		}	
		map = MovieUtils.analyse(kinds, map);
		RestTemplate restTemplate = getMovieRestTemplate();
		@SuppressWarnings("unchecked")
		//获取推荐电影的信息map
		List<String> movieId = restTemplate.postForObject("http://CALCULATE-SERVER/calculate/getid", map, List.class);
		//存储用户信息
		perferRepository.save(new UserPerfer(id, map, movieId, movieName));
		return "success";
	}
}
