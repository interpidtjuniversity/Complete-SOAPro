package com.example.demo.entity;

import java.util.List;

public class Perference {

	private String id;
	private List<String> kinds;
	//用户浏览的电影名称
	private List<String> movieName;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public List<String> getKinds() {
		return kinds;
	}

	public void setKinds(List<String> kinds) {
		this.kinds = kinds;
	}

	
	public List<String> getMovieName() {
		return movieName;
	}

	public void setMovieName(List<String> movieName) {
		this.movieName = movieName;
	}

	public Perference(String id, List<String> kinds, List<String> movieName) {
		this.id = id;
		this.kinds = kinds;
		this.movieName = movieName;
	}

	public Perference() {
	}
}
