package com.example.demo.entity;

import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("movie_info")
public class UserPerfer {

	@Id
	private String id;
	private Map<String, Integer> map;
	private List<String> movieId;
	private List<String> movieName;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Map<String, Integer> getMap() {
		return map;
	}
	public void setMap(Map<String, Integer> map) {
		this.map = map;
	}
	public List<String> getMovieId() {
		return movieId;
	}
	public void setMovieId(List<String> movieId) {
		this.movieId = movieId;
	}
	public List<String> getMovieName() {
		return movieName;
	}
	public void setMovieName(List<String> movieName) {
		this.movieName = movieName;
	}
	public UserPerfer(String id, Map<String, Integer> map, List<String> movieId, List<String> movieName) {
		this.id = id;
		this.map = map;
		this.movieId = movieId;
		this.movieName = movieName;
	}
	
	public UserPerfer() {}	
}
