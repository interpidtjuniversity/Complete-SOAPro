package com.example.demo.entity;

public class BriefMovie {

	private String id;
	private String chineseName;
	
	public BriefMovie() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getChineseName() {
		return chineseName;
	}

	public void setChineseName(String chineseName) {
		this.chineseName = chineseName;
	}

	public BriefMovie(String id, String chineseName) {
		this.id = id;
		this.chineseName = chineseName;
	}	
}
