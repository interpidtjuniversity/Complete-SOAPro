package com.example.demo.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.example.demo.entity.BriefMovie;

public class MovieUtils {

	//获取推荐电影的id，中文名
	public static List<BriefMovie> getMovieInfo(String json) {
		JSONArray movieItems = JSON.parseArray(json);
		JSONObject jsonObject = null;
		int length = movieItems.size();
		BriefMovie briefMovie = null;
		List<BriefMovie> items = new ArrayList<>();
		for(int i = 0;i<length;i++) {
			jsonObject = movieItems.getJSONObject(i);
			briefMovie = new BriefMovie();
			briefMovie.setChineseName(jsonObject.getString("chineseName"));
			briefMovie.setId(jsonObject.getString("id"));
			items.add(briefMovie);
		}
		return items;
	}
	
	//分析并存储用户的点击记录
	public static Map<String, Integer> analyse(List<String> kinds, Map<String, Integer> map) {
		String[] tags = null;
		for(String str : kinds) {
			tags = str.split(" ");
			for(String tag : tags) {
				if(map.containsKey(tag)) {
					int count = map.get(tag);
					map.put(tag, ++count);
				} else {
					map.put(tag, 1);
				}
			}
		}
		return map;
	}
}
