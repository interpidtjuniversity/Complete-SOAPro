package com.example.demo.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.util.MovieKindsUtils;

@RestController
@RequestMapping("calculate")
public class CalculateController {
	
	//通过计算余弦距离获取相似度前9电影的id
	@RequestMapping("/getid")
	public List<String> getRecommendId(@RequestBody Map<String, Integer> map) throws IOException {
		return MovieKindsUtils.getTop9(map);	
	}
}
