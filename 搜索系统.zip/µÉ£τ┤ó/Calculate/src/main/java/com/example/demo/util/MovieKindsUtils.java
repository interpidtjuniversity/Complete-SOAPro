package com.example.demo.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MovieKindsUtils {

	//获取用户特征矩阵
	public static double[] getUserMatrix(Map<String, Integer> map) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(new File("/Users/jklmnya/Desktop/kinds.txt")));
		String lines = br.readLine();
		br.close();
		Map<String, Integer> kinds = new LinkedHashMap<>();
		String[] tags = lines.split(" ");
		int index = 0;
		for(String tag : tags) {
			kinds.put(tag, index++);
		}
		//获取用户对于每种类型电影的权重
		Collection<Integer> values = map.values();
		double sum = 0;
		for(Integer num : values) {
			sum += num;
		}
		double perValue = 1 / sum;
		//用户特征矩阵
		double[] user = new double[37];
		for(Map.Entry<String, Integer> entry : map.entrySet()) {
			user[kinds.get(entry.getKey())] = entry.getValue()*perValue;
		}
		return user;
	}
	
	//获取cos值为前9的电影id
	public static List<String> getTop9(Map<String, Integer> map) throws IOException {
		double[] user = getUserMatrix(map);
		Map<String, Double> movieCos = new HashMap<>();
		BufferedReader br = new BufferedReader(new FileReader(new File("/Users/jklmnya/Desktop/matrix.txt")));
		String line = null;
		int[] item = new int[37];
		String[] tags = null;
		while((line = br.readLine()) != null) {
			tags = line.split(" ");
			for(int i = 0;i<37;i++) {
				item[i] = Integer.parseInt(tags[i]);
			}		
			movieCos.put(String.valueOf(tags[37]), getCos(user, item));
			for(int i = 0;i<37;i++) {
				item[i] = 0;
			}
		}
		br.close();
		movieCos = sortDescend(movieCos);
		Set<String> set = movieCos.keySet();
		Iterator<String> iter = set.iterator();
		List<String> top9 = new ArrayList<>();
		for(int i = 0;i<9;i++) {
			top9.add(iter.next());
		}
		return top9;
	}
	
	//计算Cos
	private static double getCos(double[] user, int[] item) {
		int length = user.length;
		double denominator = 0d;
		double numerator = 0d;
		double x = 0d;
		double y = 0d;
		for(int i = 0;i<length;i++) {
			denominator += (user[i]*item[i]);
			x += Math.pow(user[i], 2);
			y += Math.pow(item[i], 2);
		}
		numerator = Math.sqrt(x) * Math.sqrt(y);
		return denominator / numerator;
	}
	
	//map按照value值降序排序
	private static <K, V extends Comparable<? super V>> Map<K, V> sortDescend(Map<K, V> map) {
        List<Map.Entry<K, V>> list = new ArrayList<>(map.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<K, V>>() {
            @Override
            public int compare(Map.Entry<K, V> o1, Map.Entry<K, V> o2) {
                int compare = (o1.getValue()).compareTo(o2.getValue());
                return -compare;
            }
        });
        Map<K, V> returnMap = new LinkedHashMap<K, V>();
        for (Map.Entry<K, V> entry : list) {
            returnMap.put(entry.getKey(), entry.getValue());
        }
        return returnMap;
    }
}
