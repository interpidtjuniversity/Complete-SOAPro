package com.example.demo.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("news/query")
public class NewsController {

	//获取热点新闻
	@GetMapping(value = "hotNews", produces = MediaType.APPLICATION_JSON_VALUE)
	public String getHotNews() {
		final String urlStr = " http://api.avatardata.cn/ActNews/LookUp?key=09b8bbc75f71492ab224c8ac6b46fae6";
		
		HttpURLConnection httpURLConnection;
		try {
			URL url = new URL(urlStr);
			httpURLConnection = (HttpURLConnection) url.openConnection();
			httpURLConnection.connect();
			
			int errorCode = httpURLConnection.getResponseCode();
			if(errorCode == 200) {
				BufferedReader br = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream(), "utf-8"));
				StringBuffer sb = new StringBuffer();
				String temp = null;
				while((temp = br.readLine()) != null) {
					sb.append(temp);
				}
				br.close();
				return sb.toString();
			} else {
				return null;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
