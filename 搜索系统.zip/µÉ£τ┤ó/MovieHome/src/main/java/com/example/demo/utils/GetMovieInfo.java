package com.example.demo.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.example.demo.entity.Movie;

public class GetMovieInfo {

	public static Map<String, Object> getMovies(String jsonStr) {
		JSONObject jsonObject = JSONObject.parseObject(jsonStr);
		int total = jsonObject.getIntValue("totalElements");
		JSONArray moviesArray = jsonObject.getJSONArray("content");
		List<Movie> movies = new ArrayList<>();
		Movie movie = null;
		for(int i = 0;i<moviesArray.size();i++) {
			movie = new Movie();
			jsonObject = moviesArray.getJSONObject(i);
			movie.setId(jsonObject.getString("id"));
			movie.setChineseName(jsonObject.getString("chineseName"));
			movie.setOtherName(jsonObject.getString("otherName"));
			movie.setDirectors(jsonObject.getString("directors"));
			movie.setActors(jsonObject.getString("actors"));
			movie.setYear(jsonObject.getShort("year"));
			movie.setRegion(jsonObject.getString("region"));
			movie.setKinds(jsonObject.getString("kinds"));
			movie.setComment(jsonObject.getString("comment"));
			movie.setScore(jsonObject.getFloat("score"));
			movies.add(movie);
		}
		Map<String, Object> map = new HashMap<>();
		map.put("movies", movies);
		map.put("total", total);
		return map;
	}
	
	//获取电影的名称和id
	public static List<String> getMovieIdandName(String json) {
		JSONObject jsonObject = JSONObject.parseObject(json);
		jsonObject = jsonObject.getJSONObject("data");
		jsonObject = jsonObject.getJSONObject("movieByName");
		List<String> list = new ArrayList<>();
		if(jsonObject != null) {
			if(jsonObject.getString("id") == null) {
				return new ArrayList<>();
			}
			if(jsonObject.getString("name") == null) {
				return new ArrayList<>();
			}
			list.add(jsonObject.getString("id"));
			list.add(jsonObject.getString("name"));
		}
		return list;
	}
}
