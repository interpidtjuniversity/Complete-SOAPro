package com.example.demo.controller;

import java.util.List;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.example.demo.entity.News;
import com.example.demo.utils.GetNewsInfo;

@Controller
@Configuration
@RequestMapping("news")
public class NewsController {
	
	@Bean
	@LoadBalanced
	public RestTemplate getNewsRestTemplate() {
		return new RestTemplate();
	}
	
	@RequestMapping("getHotNews") 
	@ResponseBody
	public List<News> getResult() {
		RestTemplate restTemplate = getNewsRestTemplate();
		String result = restTemplate.getForObject("http://news-server/news/query/hotNews",
				String.class);
		List<News> news = GetNewsInfo.getHotNews(result);
		return news;
	}
}
