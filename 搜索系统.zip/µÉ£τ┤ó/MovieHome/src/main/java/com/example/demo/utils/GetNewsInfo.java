package com.example.demo.utils;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.example.demo.entity.News;

public class GetNewsInfo {

	//获取热点新闻
	public static List<News> getHotNews(String jsonStr) {
		JSONObject jsonObject = JSONObject.parseObject(jsonStr);
		JSONArray jsonArray = jsonObject.getJSONArray("result");
		int size = jsonArray.size();
		List<News> hotNews = new ArrayList<>();
		News news = null;
		for(int i = 0;i<size;i++) {
			news = new News(jsonArray.getString(i));
			hotNews.add(news);
		}
		return hotNews;
	}
	
	//根据关键词搜索新闻
	public static News getNewsDetail(String jsonStr) {
		return null;
	}
}
