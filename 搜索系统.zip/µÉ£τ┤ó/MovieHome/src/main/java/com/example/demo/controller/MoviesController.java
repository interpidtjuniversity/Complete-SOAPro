package com.example.demo.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.example.demo.utils.GetMovieInfo;

@Controller
@Configuration
@RequestMapping("movie")
public class MoviesController {
	
	@Bean
	@LoadBalanced
	public RestTemplate getMovieRestTemplate() {
		return new RestTemplate();
	}
	
	@GetMapping("homePage")
	public String toHomePage(String username, String token, HttpServletResponse response) {
		//判断是否携带用户名,token
		if(username == null || token == null || username.equals("") || token.equals("")) {
			try {
				//重定向到登陆界面
				response.sendRedirect("https://www.baidu.com");
			} catch (IOException e) {
				e.printStackTrace();
			}
		} 
		return "homePage";
	}
	
	@RequestMapping("queryPage")
	public String toQueryPage() {
		return "queryPage";
	}
	
	//返回数据必须以Json形式返回,模糊查询
	@RequestMapping("getResult1") 
	@ResponseBody
	public Map<String, Object> getResult(@RequestParam(value = "keyWord") String keyWord) {
		RestTemplate restTemplate = getMovieRestTemplate();
		String result = restTemplate.getForObject("http://ELASTICSEARCH-SERVER/es/query/keyword?keyWord="+keyWord,
				String.class);
		Map<String, Object> infos = GetMovieInfo.getMovies(result);
		return infos;
	}
	
	//根据地区，年代，类型查询
	@RequestMapping("getResult2")
	@ResponseBody
	public Map<String, Object> toQureyPage(@RequestParam(value = "kinds") String kinds, @RequestParam(value = "region") String region, 
			@RequestParam(value = "year") String year, @RequestParam(value = "keyWord") String keyWord, @RequestParam(value = "pageNumber") Integer pageNumber) {
		RestTemplate restTemplate = getMovieRestTemplate();
		StringBuffer url = new StringBuffer();
		url.append("http://ELASTICSEARCH-SERVER/es/query/keywords").append("?keyWord=").append(keyWord).append("&page=").append(pageNumber-1).append("&kinds=")
				.append(kinds).append("&region=").append(region).append("&year=").append(year);
		String result = restTemplate.getForObject(url.toString(), String.class);
		Map<String, Object> infos = GetMovieInfo.getMovies(result);
		return infos;
	}
	
	//根据台词搜索电影
	@GetMapping("unsatisfied")
	@ResponseBody
	public List<String> getSatisfied(@RequestParam(value = "keyWord") String keyWord) throws IOException{
		StringBuilder sb = new StringBuilder();
		sb.append("{\n").append("  movieByName(name: \"").append(keyWord).append("\") {\n").append("    id\n").append("    name\n")
					.append("  }\n").append("}");
		List<String> list = null;
        String encodeURL = URLEncoder.encode(sb.toString(), "UTF-8");
        URL url = new URL("http://172.20.10.9:8060/graphql?query="+encodeURL);
        InputStream inputStream = url.openStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
        String json = br.readLine();    
        list = GetMovieInfo.getMovieIdandName(json);
        return list;
	}
}
