package com.example.demo.entity;

public class News {

	private String title;
	
	public News() {}

	public News(String title) {
		this.title = title;
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
}
