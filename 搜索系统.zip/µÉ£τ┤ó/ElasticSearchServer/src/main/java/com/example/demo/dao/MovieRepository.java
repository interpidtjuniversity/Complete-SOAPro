package com.example.demo.dao;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import com.example.demo.entity.Movie;

public interface MovieRepository extends ElasticsearchRepository<Movie, String> {

}
