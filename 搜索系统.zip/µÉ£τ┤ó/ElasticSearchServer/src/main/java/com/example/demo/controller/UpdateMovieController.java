package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.MovieRepository;
import com.example.demo.entity.Movie;

@RestController
@RequestMapping("movie/update")
public class UpdateMovieController {

	@Autowired
	private MovieRepository movieRepository;
	
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String addMovie(@RequestBody Movie movie) {
		movieRepository.save(movie);
		return "success";
	}
	
	@RequestMapping(value = "/delete")
	@ResponseBody
	public String addMovie() {
		for(int i = 251;i<=2219;i++) {
			movieRepository.deleteById(String.valueOf(i));
		}
		return "success";
	}
}


