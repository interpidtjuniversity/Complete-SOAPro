package com.example.demo.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.QueryStringQueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.MovieRepository;
import com.example.demo.entity.Movie;

@RestController
@RequestMapping("es/query")
public class QueryMovieController {

	@Autowired
	private MovieRepository movieRepository;
	
	/**
	 * 查询评分高于用户选择的电影
	 * @return
	 * size——条目
	 * sort——排序字段
	 * direction——升序，降序
	 */
	@GetMapping(value = "score", produces = MediaType.APPLICATION_JSON_VALUE)
	public Page<Movie> getScoreGreaterMovies(String score, 
			@PageableDefault(page = 0, size = 10, sort = "score", direction = Sort.Direction.DESC) Pageable pageable) {
		QueryBuilder queryBuilder = null;
		if(score != null) {
			queryBuilder = QueryBuilders.rangeQuery("score").gte(Float.parseFloat(score));
		}
		return movieRepository.search(queryBuilder, pageable);
	}
	
	//获取指定年代的电影
	@GetMapping(value = "year", produces = MediaType.APPLICATION_JSON_VALUE)
	public Page<Movie> getYearMovies(String year, 
			@PageableDefault(page = 0, size = 10, sort = "score", direction = Sort.Direction.DESC) Pageable pageable) {
		QueryBuilder queryBuilder = null;
		if(year != null) {
			//不分词查询
			queryBuilder = QueryBuilders.termQuery("year", Short.parseShort(year));
		}
		return movieRepository.search(queryBuilder, pageable);
	}
	
	//获取所有电影
	@GetMapping(value = "all", produces = MediaType.APPLICATION_JSON_VALUE)
	public Page<Movie> getAllMovies(
			@PageableDefault(page = 0, size = 10, sort = "score", direction = Sort.Direction.DESC) Pageable pageable) {
		QueryBuilder queryBuilder = QueryBuilders.matchAllQuery();
		return movieRepository.search(queryBuilder, pageable);
	}
	
	//全字段分词检索
	@GetMapping(value = "keyword", produces = MediaType.APPLICATION_JSON_VALUE)
	public Page<Movie> getMoviesByKeyWord(String keyWord,
			@PageableDefault(page = 0, size = 10, sort = "score", direction = Sort.Direction.DESC) Pageable pageable) {
		QueryStringQueryBuilder stringQueryBuilder = new QueryStringQueryBuilder(keyWord);
		stringQueryBuilder.analyzer("ik_max_word").field("region").field("chineseName")
								.field("otherName").field("actors").field("directors");
		return movieRepository.search(stringQueryBuilder, pageable);
	}
	
	//根据年代，类型，地区以及关键字查询
	@GetMapping(value = "keywords", produces = MediaType.APPLICATION_JSON_VALUE)
	public Page<Movie> getMoviesByKeyWords(String keyWord, String kinds, String region, String year,
			@PageableDefault(page = 0, size = 10, sort = "score", direction = Sort.Direction.DESC) Pageable pageable) {
		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
		if(!keyWord.equals("") || keyWord != null) {
			QueryStringQueryBuilder stringQueryBuilder = new QueryStringQueryBuilder(keyWord);
			stringQueryBuilder.analyzer("ik_max_word").field("chineseName")
								.field("otherName").field("actors").field("directors");
			boolQueryBuilder.should(stringQueryBuilder);
		}
		if(!kinds.equals("全部")) {
			if(!kinds.equals("其他")) {
				boolQueryBuilder.must(QueryBuilders.wildcardQuery("kinds", "*"+kinds+"*"));
			}
		}
		if(!region.equals("全部")) {
			if(!kinds.equals("其他")) {
				boolQueryBuilder.must(QueryBuilders.wildcardQuery("region", "*"+region+"*"));
			}
		}
		if(!year.equals("全部")) {	
			if(year.equals("其他")) {
				boolQueryBuilder.must(QueryBuilders.rangeQuery("year").lt(2014));
			} else {
				boolQueryBuilder.must(QueryBuilders.termQuery("year", Short.parseShort(year)));
			}			
		}
		return movieRepository.search(boolQueryBuilder, pageable);
	}
	
	//根据地区查询电影
	@GetMapping(value = "region", produces = MediaType.APPLICATION_JSON_VALUE)
	public Page<Movie> getMoviesByRegion(String region,
			@PageableDefault(page = 0, size = 10, sort = "score", direction = Sort.Direction.DESC) Pageable pageable) {
		QueryBuilder queryBuilder = null;
		if(region != null) {
			queryBuilder = QueryBuilders.wildcardQuery("region", "*"+region+"*");
		}
		return movieRepository.search(queryBuilder, pageable);
	}
	
	//根据分类查询电影
	@GetMapping(value = "kinds", produces = MediaType.APPLICATION_JSON_VALUE)
	public Page<Movie> getMoviesByKinds(String kinds,
			@PageableDefault(page = 0, size = 10, sort = "score", direction = Sort.Direction.DESC) Pageable pageable) {
		QueryBuilder queryBuilder = null;
		if(kinds != null) {
			queryBuilder = QueryBuilders.wildcardQuery("kinds", "*"+kinds+"*");
		}
		return movieRepository.search(queryBuilder, pageable);
	}
	
	//推荐电影，返回电影的中文名称，id
	@RequestMapping(value = "recommend", produces = MediaType.APPLICATION_JSON_VALUE)
	public Iterable<Movie> getRecommandMovies(@RequestBody List<String> movieId) {
		return movieRepository.findAllById(movieId);
	}
	
	//根据电影名称获取电影类型
	@GetMapping(value = "getkinds")
	public Set<String> getKindsByName(@RequestParam String movieName) {
		QueryStringQueryBuilder stringQueryBuilder = new QueryStringQueryBuilder(movieName);
		stringQueryBuilder.analyzer("ik_max_word").field("chineseName").field("otherName");
		Iterable<Movie> iter = movieRepository.search(stringQueryBuilder);
		Set<String> kinds = new HashSet<>();
		String[] strs = null;
		for(Movie movie : iter) {
			strs = movie.getKinds().split(" ");
			for(String str : strs) {
				kinds.add(str);
			}
		}
		return kinds;
	}
}